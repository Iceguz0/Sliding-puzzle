import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import "@fontsource/inter";
import { usePuzzle } from "./lib/stores/usePuzzle";
import { Menu } from "./components/Menu";
import { PuzzleScene } from "./components/PuzzleScene";
import { GameHUD } from "./components/GameHUD";
import { WinScreen } from "./components/WinScreen";
import { SoundManager } from "./components/SoundManager";

function App() {
  const phase = usePuzzle(state => state.phase);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      {phase === 'menu' && <Menu />}

      {(phase === 'playing' || phase === 'won') && (
        <>
          <Canvas
            shadows
            camera={{
              position: [0, 8, 8],
              fov: 50,
              near: 0.1,
              far: 1000
            }}
            gl={{
              antialias: true,
              powerPreference: "default"
            }}
          >
            <Suspense fallback={null}>
              <PuzzleScene />
            </Suspense>
          </Canvas>
          
          <GameHUD />
          {phase === 'won' && <WinScreen />}
        </>
      )}

      <SoundManager />
    </div>
  );
}

export default App;
