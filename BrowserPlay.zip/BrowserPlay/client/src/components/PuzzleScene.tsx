import { OrbitControls } from "@react-three/drei";
import { PuzzleBoard } from "./PuzzleBoard";

export function PuzzleScene() {
  return (
    <>
      <color attach="background" args={["#1e293b"]} />
      
      <ambientLight intensity={0.5} />
      <directionalLight
        position={[5, 10, 5]}
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      <pointLight position={[-5, 5, -5]} intensity={0.3} />
      
      <PuzzleBoard />
      
      <OrbitControls
        enablePan={false}
        minDistance={5}
        maxDistance={15}
        minPolarAngle={Math.PI / 6}
        maxPolarAngle={Math.PI / 2.5}
      />
    </>
  );
}
