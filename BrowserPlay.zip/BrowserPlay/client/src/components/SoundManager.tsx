import { useEffect } from "react";
import { useAudio } from "@/lib/stores/useAudio";
import { usePuzzle } from "@/lib/stores/usePuzzle";
import { Button } from "./ui/button";
import { Volume2, VolumeX } from "lucide-react";

export function SoundManager() {
  const { 
    setBackgroundMusic, 
    setHitSound, 
    setSuccessSound,
    isMuted,
    toggleMute,
    playHit,
    playSuccess
  } = useAudio();
  
  const phase = usePuzzle(state => state.phase);
  const moves = usePuzzle(state => state.moves);
  
  useEffect(() => {
    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.3;
    setBackgroundMusic(bgMusic);
    
    const hit = new Audio("/sounds/hit.mp3");
    setHitSound(hit);
    
    const success = new Audio("/sounds/success.mp3");
    setSuccessSound(success);
  }, [setBackgroundMusic, setHitSound, setSuccessSound]);
  
  useEffect(() => {
    if (moves > 0) {
      playHit();
    }
  }, [moves, playHit]);
  
  useEffect(() => {
    if (phase === "won") {
      playSuccess();
    }
  }, [phase, playSuccess]);
  
  return (
    <div className="fixed bottom-4 right-4 z-20">
      <Button
        onClick={toggleMute}
        variant="outline"
        size="icon"
        className="bg-slate-800/90 border-slate-700 text-white hover:bg-slate-700 backdrop-blur w-12 h-12"
      >
        {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
      </Button>
    </div>
  );
}
