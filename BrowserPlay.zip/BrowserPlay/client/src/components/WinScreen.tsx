import { usePuzzle } from "@/lib/stores/usePuzzle";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Trophy, Timer, Hash } from "lucide-react";
import { useEffect, useState } from "react";
import Confetti from "react-confetti";

export function WinScreen() {
  const { time, moves, level, nextLevel, resetGame, backToMenu, levelStats } = usePuzzle();
  const [windowSize, setWindowSize] = useState({ width: window.innerWidth, height: window.innerHeight });
  
  useEffect(() => {
    const handleResize = () => {
      setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    };
    
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  const levelNames = ['Easy', 'Medium', 'Hard'];
  const hasNextLevel = level < 3;
  
  const currentStats = levelStats[level];
  const isNewBestTime = currentStats.bestTime === time;
  const isNewBestMoves = currentStats.bestMoves === moves;
  
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm z-50">
      <Confetti
        width={windowSize.width}
        height={windowSize.height}
        recycle={true}
        numberOfPieces={200}
      />
      <Card className="w-full max-w-md mx-4 bg-slate-800/95 border-slate-700">
        <CardHeader>
          <div className="flex flex-col items-center gap-2">
            <Trophy className="w-16 h-16 text-yellow-400" />
            <CardTitle className="text-3xl font-bold text-center text-white">
              Puzzle Solved!
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-slate-900/50 rounded-lg p-4 space-y-3">
            <div className="flex justify-between text-white">
              <span className="flex items-center gap-2">
                <span className="text-slate-400">Level:</span>
              </span>
              <span className="font-semibold text-blue-300">{levelNames[level - 1]}</span>
            </div>
            
            <div className="flex justify-between text-white">
              <span className="flex items-center gap-2">
                <Timer className="w-4 h-4 text-green-400" />
                <span className="text-slate-400">Time:</span>
              </span>
              <span className="font-mono text-green-300">
                {formatTime(time)}
                {isNewBestTime && <span className="ml-2 text-yellow-400">★ New Best!</span>}
              </span>
            </div>
            
            <div className="flex justify-between text-white">
              <span className="flex items-center gap-2">
                <Hash className="w-4 h-4 text-yellow-400" />
                <span className="text-slate-400">Moves:</span>
              </span>
              <span className="font-mono text-yellow-300">
                {moves}
                {isNewBestMoves && <span className="ml-2 text-yellow-400">★ New Best!</span>}
              </span>
            </div>
            
            {currentStats.bestTime !== null && !isNewBestTime && (
              <div className="pt-2 border-t border-slate-700">
                <div className="flex justify-between text-white text-sm">
                  <span className="text-slate-400">Best Time:</span>
                  <span className="font-mono text-green-400">{formatTime(currentStats.bestTime)}</span>
                </div>
              </div>
            )}
            
            {currentStats.bestMoves !== null && !isNewBestMoves && (
              <div className={currentStats.bestTime === null || isNewBestTime ? "pt-2 border-t border-slate-700" : ""}>
                <div className="flex justify-between text-white text-sm">
                  <span className="text-slate-400">Best Moves:</span>
                  <span className="font-mono text-yellow-400">{currentStats.bestMoves}</span>
                </div>
              </div>
            )}
          </div>
          
          <div className="space-y-3">
            {hasNextLevel && (
              <Button
                onClick={nextLevel}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white text-lg py-6"
              >
                Next Level
              </Button>
            )}
            
            <Button
              onClick={resetGame}
              variant="outline"
              className="w-full bg-slate-700 hover:bg-slate-600 text-white border-slate-600 text-lg py-6"
            >
              Play Again
            </Button>
            
            <Button
              onClick={backToMenu}
              variant="outline"
              className="w-full bg-slate-700 hover:bg-slate-600 text-white border-slate-600"
            >
              Back to Menu
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
