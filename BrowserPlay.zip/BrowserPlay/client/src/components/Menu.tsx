import { usePuzzle } from "@/lib/stores/usePuzzle";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { CheckCircle2 } from "lucide-react";

export function Menu() {
  const { startGame, levelStats } = usePuzzle();
  
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 z-50">
      <Card className="w-full max-w-md mx-4 bg-slate-800/90 border-slate-700 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-4xl font-bold text-center text-white">
            Sliding Puzzle
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-center text-slate-300 mb-6">
            Rearrange the tiles to solve the puzzle. Click on tiles adjacent to the empty space to move them.
          </p>
          
          <div className="space-y-3">
            <Button
              onClick={() => startGame(1)}
              className="w-full bg-green-600 hover:bg-green-700 text-white text-lg py-6 flex items-center justify-center gap-2"
            >
              <span>Easy (3×3)</span>
              {levelStats[1]?.completed && <CheckCircle2 className="w-5 h-5" />}
            </Button>
            
            <Button
              onClick={() => startGame(2)}
              className="w-full bg-yellow-600 hover:bg-yellow-700 text-white text-lg py-6 flex items-center justify-center gap-2"
            >
              <span>Medium (4×4)</span>
              {levelStats[2]?.completed && <CheckCircle2 className="w-5 h-5" />}
            </Button>
            
            <Button
              onClick={() => startGame(3)}
              className="w-full bg-red-600 hover:bg-red-700 text-white text-lg py-6 flex items-center justify-center gap-2"
            >
              <span>Hard (5×5)</span>
              {levelStats[3]?.completed && <CheckCircle2 className="w-5 h-5" />}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
