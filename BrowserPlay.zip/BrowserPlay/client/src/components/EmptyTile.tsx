import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface EmptyTileProps {
  position: number;
  gridSize: number;
}

export function EmptyTile({ position, gridSize }: EmptyTileProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const initializedRef = useRef(false);
  const targetRef = useRef({ x: 0, z: 0 });
  
  const getGridPosition = (pos: number): [number, number] => {
    const row = Math.floor(pos / gridSize);
    const col = pos % gridSize;
    return [col, row];
  };
  
  const [targetCol, targetRow] = getGridPosition(position);
  const targetX = (targetCol - (gridSize - 1) / 2) * 1.1;
  const targetZ = (targetRow - (gridSize - 1) / 2) * 1.1;
  
  useEffect(() => {
    if (meshRef.current && !initializedRef.current) {
      meshRef.current.position.set(targetX, -0.05, targetZ);
      targetRef.current = { x: targetX, z: targetZ };
      initializedRef.current = true;
    } else {
      targetRef.current = { x: targetX, z: targetZ };
    }
  }, [targetX, targetZ]);
  
  useFrame(() => {
    if (meshRef.current && initializedRef.current) {
      meshRef.current.position.x += (targetRef.current.x - meshRef.current.position.x) * 0.2;
      meshRef.current.position.z += (targetRef.current.z - meshRef.current.position.z) * 0.2;
    }
  });
  
  return (
    <mesh ref={meshRef}>
      <boxGeometry args={[1, 0.1, 1]} />
      <meshStandardMaterial 
        color="#1e293b" 
        transparent 
        opacity={0.3}
      />
    </mesh>
  );
}
