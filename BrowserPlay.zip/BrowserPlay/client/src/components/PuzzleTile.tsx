import { useRef, useState, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { Text } from "@react-three/drei";

interface PuzzleTileProps {
  id: number;
  position: number;
  targetPosition: number;
  gridSize: number;
  onClick: () => void;
  isHint: boolean;
}

export function PuzzleTile({ id, position, targetPosition, gridSize, onClick, isHint }: PuzzleTileProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const initializedRef = useRef(false);
  const targetRef = useRef({ x: 0, z: 0 });
  const [hovered, setHovered] = useState(false);
  
  const getGridPosition = (pos: number): [number, number] => {
    const row = Math.floor(pos / gridSize);
    const col = pos % gridSize;
    return [col, row];
  };
  
  const [targetCol, targetRow] = getGridPosition(targetPosition);
  const targetX = (targetCol - (gridSize - 1) / 2) * 1.1;
  const targetZ = (targetRow - (gridSize - 1) / 2) * 1.1;
  
  useEffect(() => {
    if (meshRef.current && !initializedRef.current) {
      meshRef.current.position.set(targetX, 0, targetZ);
      targetRef.current = { x: targetX, z: targetZ };
      initializedRef.current = true;
    } else {
      targetRef.current = { x: targetX, z: targetZ };
    }
  }, [targetX, targetZ]);
  
  useFrame(() => {
    if (meshRef.current && initializedRef.current) {
      meshRef.current.position.x += (targetRef.current.x - meshRef.current.position.x) * 0.2;
      meshRef.current.position.z += (targetRef.current.z - meshRef.current.position.z) * 0.2;
      
      const targetScale = hovered ? 1.05 : 1.0;
      meshRef.current.scale.x += (targetScale - meshRef.current.scale.x) * 0.1;
      meshRef.current.scale.y += (targetScale - meshRef.current.scale.y) * 0.1;
      meshRef.current.scale.z += (targetScale - meshRef.current.scale.z) * 0.1;
    }
  });
  
  const isCorrect = position === id;
  let color = isCorrect ? "#4ade80" : "#3b82f6";
  let emissive = "#000000";
  let emissiveIntensity = 0;
  
  if (isHint) {
    color = "#fbbf24";
    emissive = "#f59e0b";
    emissiveIntensity = 0.5;
  } else if (hovered) {
    color = "#60a5fa";
    emissive = "#1e40af";
    emissiveIntensity = 0.2;
  }
  
  return (
    <mesh
      ref={meshRef}
      onClick={onClick}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      <boxGeometry args={[1, 0.2, 1]} />
      <meshStandardMaterial 
        color={color} 
        emissive={emissive}
        emissiveIntensity={emissiveIntensity}
      />
      <Text
        position={[0, 0.11, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        fontSize={0.4}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        {id + 1}
      </Text>
    </mesh>
  );
}
