import { usePuzzle } from "@/lib/stores/usePuzzle";
import { PuzzleTile } from "./PuzzleTile";
import { EmptyTile } from "./EmptyTile";
import { useTexture } from "@react-three/drei";

export function PuzzleBoard() {
  const { tiles, moveTile, gridSize, emptyPosition, hintPosition } = usePuzzle();
  const woodTexture = useTexture("/textures/wood.jpg");
  
  const boardSize = gridSize * 1.1 + 0.5;
  
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.15, 0]} receiveShadow>
        <planeGeometry args={[boardSize, boardSize]} />
        <meshStandardMaterial map={woodTexture} />
      </mesh>
      
      <EmptyTile position={emptyPosition} gridSize={gridSize} />
      
      {tiles.map((tile) => (
        <PuzzleTile
          key={tile.id}
          id={tile.id}
          position={tile.position}
          targetPosition={tile.position}
          gridSize={gridSize}
          onClick={() => moveTile(tile.position)}
          isHint={tile.position === hintPosition}
        />
      ))}
    </group>
  );
}
