import { useEffect } from "react";
import { usePuzzle } from "@/lib/stores/usePuzzle";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Timer, Hash, Grid3x3, Lightbulb, Undo } from "lucide-react";

export function GameHUD() {
  const { time, moves, level, gridSize, incrementTime, resetGame, backToMenu, showHint, undoMove, moveHistory } = usePuzzle();
  
  useEffect(() => {
    const interval = setInterval(() => {
      incrementTime();
    }, 1000);
    
    return () => clearInterval(interval);
  }, [incrementTime]);
  
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  const levelNames = ['Easy', 'Medium', 'Hard'];
  
  return (
    <div className="fixed top-0 left-0 right-0 p-4 z-10 pointer-events-none">
      <div className="max-w-6xl mx-auto flex justify-between items-start gap-4">
        <Card className="bg-slate-800/90 border-slate-700 backdrop-blur pointer-events-auto">
          <div className="p-4 space-y-2">
            <div className="flex items-center gap-2 text-white">
              <Grid3x3 className="w-5 h-5 text-blue-400" />
              <span className="font-semibold">Level:</span>
              <span className="text-blue-300">{levelNames[level - 1]} ({gridSize}×{gridSize})</span>
            </div>
            
            <div className="flex items-center gap-2 text-white">
              <Timer className="w-5 h-5 text-green-400" />
              <span className="font-semibold">Time:</span>
              <span className="text-green-300 font-mono">{formatTime(time)}</span>
            </div>
            
            <div className="flex items-center gap-2 text-white">
              <Hash className="w-5 h-5 text-yellow-400" />
              <span className="font-semibold">Moves:</span>
              <span className="text-yellow-300 font-mono">{moves}</span>
            </div>
          </div>
        </Card>
        
        <div className="flex gap-2 pointer-events-auto">
          <Button
            onClick={showHint}
            variant="outline"
            className="bg-slate-800/90 border-slate-700 text-white hover:bg-slate-700"
            title="Show hint"
          >
            <Lightbulb className="w-4 h-4" />
          </Button>
          <Button
            onClick={undoMove}
            variant="outline"
            className="bg-slate-800/90 border-slate-700 text-white hover:bg-slate-700"
            disabled={moveHistory.length === 0}
            title="Undo last move"
          >
            <Undo className="w-4 h-4" />
          </Button>
          <Button
            onClick={resetGame}
            variant="outline"
            className="bg-slate-800/90 border-slate-700 text-white hover:bg-slate-700"
          >
            Reset
          </Button>
          <Button
            onClick={backToMenu}
            variant="outline"
            className="bg-slate-800/90 border-slate-700 text-white hover:bg-slate-700"
          >
            Menu
          </Button>
        </div>
      </div>
    </div>
  );
}
