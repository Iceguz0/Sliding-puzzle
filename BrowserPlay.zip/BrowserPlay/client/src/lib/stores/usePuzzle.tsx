import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type PuzzlePhase = "menu" | "playing" | "won";

interface Tile {
  id: number;
  position: number;
  correctPosition: number;
}

interface LevelStats {
  bestTime: number | null;
  bestMoves: number | null;
  completed: boolean;
}

interface PuzzleState {
  phase: PuzzlePhase;
  tiles: Tile[];
  emptyPosition: number;
  moves: number;
  time: number;
  level: number;
  gridSize: number;
  hintPosition: number | null;
  moveHistory: Array<{ tilePosition: number; emptyPosition: number }>;
  levelStats: Record<number, LevelStats>;
  
  startGame: (level: number) => void;
  moveTile: (position: number) => void;
  incrementTime: () => void;
  checkWin: () => void;
  nextLevel: () => void;
  resetGame: () => void;
  backToMenu: () => void;
  showHint: () => void;
  clearHint: () => void;
  undoMove: () => void;
  loadProgress: () => void;
  saveProgress: () => void;
}

const generatePuzzle = (gridSize: number): { tiles: Tile[], emptyPosition: number } => {
  const totalTiles = gridSize * gridSize;
  const tiles: Tile[] = [];
  
  for (let i = 0; i < totalTiles - 1; i++) {
    tiles.push({
      id: i,
      position: i,
      correctPosition: i,
    });
  }
  
  const initialEmptyPosition = totalTiles - 1;
  
  const { tiles: shuffledTiles, emptyPosition } = shufflePuzzle(tiles, initialEmptyPosition, gridSize);
  
  return { tiles: shuffledTiles, emptyPosition };
};

const shufflePuzzle = (tiles: Tile[], emptyPos: number, gridSize: number): { tiles: Tile[], emptyPosition: number } => {
  const shuffled = [...tiles];
  let currentEmpty = emptyPos;
  
  for (let i = 0; i < 100; i++) {
    const neighbors = getNeighbors(currentEmpty, gridSize);
    const randomNeighbor = neighbors[Math.floor(Math.random() * neighbors.length)];
    
    const tileIndex = shuffled.findIndex(t => t.position === randomNeighbor);
    if (tileIndex !== -1) {
      shuffled[tileIndex].position = currentEmpty;
      currentEmpty = randomNeighbor;
    }
  }
  
  return { tiles: shuffled, emptyPosition: currentEmpty };
};

const getNeighbors = (position: number, gridSize: number): number[] => {
  const neighbors: number[] = [];
  const row = Math.floor(position / gridSize);
  const col = position % gridSize;
  
  if (row > 0) neighbors.push(position - gridSize);
  if (row < gridSize - 1) neighbors.push(position + gridSize);
  if (col > 0) neighbors.push(position - 1);
  if (col < gridSize - 1) neighbors.push(position + 1);
  
  return neighbors;
};

const STORAGE_KEY = "sliding-puzzle-progress";

const loadStatsFromStorage = (): Record<number, LevelStats> => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (error) {
    console.error("Failed to load progress:", error);
  }
  
  return {
    1: { bestTime: null, bestMoves: null, completed: false },
    2: { bestTime: null, bestMoves: null, completed: false },
    3: { bestTime: null, bestMoves: null, completed: false },
  };
};

const saveStatsToStorage = (stats: Record<number, LevelStats>) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  } catch (error) {
    console.error("Failed to save progress:", error);
  }
};

export const usePuzzle = create<PuzzleState>()(
  subscribeWithSelector((set, get) => ({
    phase: "menu",
    tiles: [],
    emptyPosition: 0,
    moves: 0,
    time: 0,
    level: 1,
    gridSize: 3,
    hintPosition: null,
    moveHistory: [],
    levelStats: loadStatsFromStorage(),
    
    startGame: (level: number) => {
      const gridSize = level === 1 ? 3 : level === 2 ? 4 : 5;
      const { tiles, emptyPosition } = generatePuzzle(gridSize);
      
      set({
        phase: "playing",
        tiles,
        emptyPosition,
        moves: 0,
        time: 0,
        level,
        gridSize,
        hintPosition: null,
        moveHistory: [],
      });
    },
    
    moveTile: (position: number) => {
      const { tiles, emptyPosition, gridSize, phase, moveHistory, moves } = get();
      
      if (phase !== "playing") return;
      
      const neighbors = getNeighbors(emptyPosition, gridSize);
      if (!neighbors.includes(position)) return;
      
      const newTiles = tiles.map(tile => {
        if (tile.position === position) {
          return { ...tile, position: emptyPosition };
        }
        return tile;
      });
      
      const newMoves = moves + 1;
      const newHistory = [...moveHistory, { tilePosition: position, emptyPosition }];
      
      if (newHistory.length !== newMoves) {
        console.error(`Move history desync: history.length=${newHistory.length}, moves=${newMoves}`);
      }
      
      set({
        tiles: newTiles,
        emptyPosition: position,
        moves: newMoves,
        hintPosition: null,
        moveHistory: newHistory,
      });
      
      setTimeout(() => get().checkWin(), 100);
    },
    
    incrementTime: () => {
      if (get().phase === "playing") {
        set({ time: get().time + 1 });
      }
    },
    
    checkWin: () => {
      const { tiles, level, time, moves, levelStats } = get();
      const isWon = tiles.every(tile => tile.position === tile.id);
      
      if (isWon) {
        console.log("Puzzle solved!");
        
        const currentStats = levelStats[level];
        const isNewBestTime = !currentStats.bestTime || time < currentStats.bestTime;
        const isNewBestMoves = !currentStats.bestMoves || moves < currentStats.bestMoves;
        
        const updatedStats = {
          ...levelStats,
          [level]: {
            bestTime: isNewBestTime ? time : currentStats.bestTime,
            bestMoves: isNewBestMoves ? moves : currentStats.bestMoves,
            completed: true,
          },
        };
        
        saveStatsToStorage(updatedStats);
        
        set({ 
          phase: "won",
          levelStats: updatedStats,
          moveHistory: [],
        });
      }
    },
    
    nextLevel: () => {
      const nextLevel = get().level + 1;
      if (nextLevel <= 3) {
        get().startGame(nextLevel);
      }
    },
    
    resetGame: () => {
      get().startGame(get().level);
    },
    
    backToMenu: () => {
      set({
        phase: "menu",
        tiles: [],
        emptyPosition: 0,
        moves: 0,
        time: 0,
        hintPosition: null,
        moveHistory: [],
      });
    },
    
    showHint: () => {
      const { emptyPosition, gridSize, phase } = get();
      
      if (phase !== "playing") return;
      
      const neighbors = getNeighbors(emptyPosition, gridSize);
      if (neighbors.length > 0) {
        const randomHint = neighbors[Math.floor(Math.random() * neighbors.length)];
        set({ hintPosition: randomHint });
        
        setTimeout(() => {
          set({ hintPosition: null });
        }, 2000);
      }
    },
    
    clearHint: () => {
      set({ hintPosition: null });
    },
    
    undoMove: () => {
      const { moveHistory, tiles, phase, moves } = get();
      
      if (phase !== "playing" || moveHistory.length === 0) return;
      
      const lastMove = moveHistory[moveHistory.length - 1];
      const newHistory = moveHistory.slice(0, -1);
      
      const newTiles = tiles.map(tile => {
        if (tile.position === lastMove.emptyPosition) {
          return { ...tile, position: lastMove.tilePosition };
        }
        return tile;
      });
      
      set({
        tiles: newTiles,
        emptyPosition: lastMove.emptyPosition,
        moveHistory: newHistory,
        hintPosition: null,
        moves: Math.max(0, moves - 1),
      });
    },
    
    loadProgress: () => {
      const stats = loadStatsFromStorage();
      set({ levelStats: stats });
    },
    
    saveProgress: () => {
      const { levelStats } = get();
      saveStatsToStorage(levelStats);
    },
  }))
);
